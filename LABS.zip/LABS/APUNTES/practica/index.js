import chalk from 'chalk'
console.log(chalk.bold('LOLO'))