const { sequelize } = require("../../db/db");
const { DataTypes } = require("sequelize");

const Actor = sequelize.define("actor", {
  firstName: {
    type: DataTypes.STRING, //tipo de dato en la columna: STRING
    allowNull: false,
  },
  lastName: {
    type: DataTypes.STRING, //tipo de dato en la columna: STRING
    allowNull: false,
  },
});

module.exports = Actor;
