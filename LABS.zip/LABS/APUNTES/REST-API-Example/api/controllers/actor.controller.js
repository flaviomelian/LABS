const { response } = require("express");
const Actor = require("../models/actor.model");
const Movie = require("../models/movie.model");
const getActorMoviesLazy = async (request, response) => {
  try {
    const actor = await Actor.findOne({
      where: {
        id: request.params.id, //filtrar por id
      },
    }); //guardamos el actor en una constante con findOne()
    const movies = await actor.getMovies();
    return response.status(200).json({ actor, movies });
  } catch (error) {
    return response.status(404).send(error); //en caso de error, devolemos el codigo de error y enviamos el mensaje de error
  }
};

const getActorMoviesEager = async (request, response) => {
  try {
    const actor = await Actor.findOne({
      where: {
        id: request.params.id, //filtrar por id
      },
      include: Movie,
    }); //guardamos el actor en una constante con findOne()
    return response.status(200).json(actor);
  } catch (error) {
    return response.status(404).send(error); //en caso de error, devolemos el codigo de error y enviamos el mensaje de error
  }
};

module.exports = { getActorMoviesEager, getActorMoviesLazy };
