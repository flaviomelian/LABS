const router = require("express").Router(); //importar el router de express
const userRouter = require("./user.router"); //importar el router de los usuarios
const movieRouter = require("./movie.router"); //importar el router de las pelis
const actorRouter = require("./actor.router"); //importar el router de los actores
router.use("/users", userRouter); //asignamos al router principal el de los usuarios al acceder al endpoint /
router.use("/movies", movieRouter); //asignamos al router principal el de las pelis al acceder al endpoint /
router.use("/actors", movieRouter); //asignamos al router principal el de las pelis al acceder al endpoint /
module.exports = { userRouter, movieRouter }; //exportamos los routers que queremos usar
