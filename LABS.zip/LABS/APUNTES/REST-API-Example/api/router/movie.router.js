const router = require("express").Router(); //importar el router de express

const {
  getAllMovies,
  createMovie,
  getMovie,
  updateMovie,
  deleteMovie,
  addActorToMovie,
} = require("../controllers/movie.controller"); //traernos los controladores

//rutas con paramateros y controladores con su método HTTP
router.get("/", getAllMovies);
router.get("/:id", getMovie);
router.post("/", createMovie);
router.put("/:id", updateMovie);
router.delete("/:id", deleteMovie);
router.put("/:id/actor/:actor_id", addActorToMovie);
module.exports = router; //exportar el router
