const router = require("express").Router(); //importar el router de express

const {
  getActorMoviesEager,
  getActorMoviesLazy,
} = require("../controllers/actor.controller"); //traernos los controladores

//rutas con paramateros y controladores con su método HTTP
router.get("/:id/movies/eager", getActorMoviesEager);
router.get("/:id/movies/lazy", getActorMoviesLazy);

module.exports = router; //exportar el router

