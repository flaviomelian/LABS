//configuraciones del servidor:
const express = require("express");
const morgan = require("morgan");
const api = express();
const port = 3001;

api.use(express.static("public")); //acceso a carpetas estáticas en el equipo
api.use(morgan("dev")); //instalacion de morgan
api.use(express.urlencoded({ extended: false })); //instalacion de express
api.use(express.json());

//se le dice que escuche en un puerto y un console log para ver que todo va bien: Se levanta el servidor en dicho puerto
api.listen(port, () => {
  console.log(`lolo listening at port ${port}`);
});

//toma la ruta y se le dice lo que tiene que hacer: Solicitud get
api.get("/api", (request, response) => {
  console.log(request);
  response.send("<p>Espabila, que la vida te va a comer</p>");
});

//paso de parametros (/:id)
api.get("/api/user/:id", (request, response) => {
  console.log(request.params.id);
  response.send(
    "<p>Espabila "
      .concat(request.params.id)
      .concat(", que la vida te va a comer</p>")
  );
});

//post (subida al servidor)
api.post("/api/user", (request, response) => {
  response.send(request.body);
});
