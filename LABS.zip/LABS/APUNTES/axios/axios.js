const axios = require("axios");
const getTodos = async () => {
  try {
    const data = await axios.get("https://jsonplaceholder.typicode.com/todos");
    console.log(data);
  } catch (error) {
    throw new Error(error);
  }
};

const getTodo = async (id) => {
  try {
    const data = await axios.get(
      `https://jsonplaceholder.typicode.com/todos/${id}`
    );
    console.log(data);
  } catch (error) {
    throw new Error(error);
  }
};

const addTodo = async () => {
  try {
    const { data } = await axios.post(
      `https://jsonplaceholder.typicode.com/todos/`,
      {
        userId: 1,
        title: "Llorar en la lloreria",
        completed: true,
      }
    );
    console.log(data);
  } catch (error) {
    throw new Error(error);
  }
};

const updateTodo = async () => {
  try {
    const { data } = await axios.put(
      `https://jsonplaceholder.typicode.com/todos/`,
      {
        userId: 1,
        title: "gritar arriba españa",
        completed: true,
      }
    );
    console.log(data);
  } catch (error) {
    throw new Error(error);
  }
};

const deleteTodo = async (id) => {
  try {
    const data = await axios.delete(
      `https://jsonplaceholder.typicode.com/todos/${id}`
    );
    console.log(data);
  } catch (error) {
    throw new Error(error);
  }
};

getTodos();
addTodo();
//updateTodo();
getTodo(5);
deleteTodo(5);
getTodo(5);
