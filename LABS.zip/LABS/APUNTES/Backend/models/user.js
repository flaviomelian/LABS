const { sequelize } = require("../back.js");
const { DataTypes } = require("sequelize");

const User = sequelize.define("User", {
  firstname: {
    type: DataTypes.STRING,
    unique: true,
  },
});

(async function () {
  try {
    await User.sync({ alter: true });
  } catch (error) {
    console.error(error);
  }
})();

async function createUser() {
  const lolo = await User.create({ firstname: "LOLO" });
}

createUser();
