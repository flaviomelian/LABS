require("dotenv").config();
const { Sequelize } = require("sequelize");

const sequelize = new Sequelize("SeqPrueba", "flavio", "flavio", {
  host: "localhost",
  dialect: "mysql",
  port: 3306,
  logging: false,
});

(async function () {
  try {
    await sequelize.authenticate();
    console.log("Successful Connection");
  } catch (error) {
    console.error(error);
  }
})();

module.exports = { sequelize };
