![](https://user-images.githubusercontent.com/970858/63474771-d6734700-c469-11e9-83bb-9429da563909.png)


# API introduction Lab - Flavio Melián Santana

## Introduction

We've only learned the basics of API communication today, but what can we do with an API? We hope you are ready to get your mind blown!

We are going to work just with postman to send petitions to [The Cocktail DB](https://www.thecocktaildb.com/)

## Requirements

- [Learn how to fork this repo](https://guides.github.com/activities/forking/)
- Clone this repo into your `code/labs` folder
- Paste the screen of the activities on this file. (remember to upload images).
- Answer all the questions done on this file (take pictures when needed).
- Use postman to retrieve/send the data.

## Questions

1. **What is an API?**
An Application Program Interface is a set of tools, protocols and routines, source code, ultimately, which specifies how software should interact with a web application

2. **What does any API respond if you send something wrong on a request?** (take a picture with postman on one api you have chosen)
The API indicates you that you've made a mistake on your request

3. **Which HTTP verb is used for updating data?**
PATCH

4. **Which HTTP verb is used for deleting data?**
DELETE

5. **What does SOLID mean and why it's useful?** (go a bit deeper reasearching!)
SOLID principles are five rules of OOP that mean Single Responsibility Principle: the fact of every class must have only one and no more reasons to change. Basicallly the class is developed for only one functionality. Open/Close Principle: the classes must be able to be extended in a future so that their code has not to be modified. Liskov Substition Principle: childs of a class must be able to replace their parent keeping the program working intact. Interface Segregation Principle: interfaces must be the most specific possible in order to get more modularity of source code. Dependency Inversion Principle: the high level code must not have dependencies on low level modules, both must depend on abstractions which don't depend on abstractions, but the other way around.

SOLID is useful because grant us certain benefits like next ones:
-   Maintainability:
    Is easier to understand a SOLID principles based code because we can identify on an easier way the responsibility of every class, and this makes it easier to locate errors.

-   Reuse:
    SOLID makes the code more modular and this allows us find ways of use our code to solve more tasks on different contexts.

-   Extensibility:
    As we are using the Open/Close and the Liskov Substition Principles, software can be adapted to new requirements without rewrite its code.

-   Decoupling:
    Dependency Inversion Principle promotes a decoupled design, so individual components can be easily integrated and proved and bring us more flexibility on our system.

## Mission 1

- Get all drinks that have `milk` as ingredient: https://www.thecocktaildb.com/api/json/v1/1/filter.php?i=milk

## Mission 2

- Get all drinks made with `Orange`: https://www.thecocktaildb.com/api/json/v1/1/filter.php?i=orange
- Show a preview of the `first cocktail`: https://www.thecocktaildb.com/api/json/v1/1/search.php?i=1

## Mission 3

- Get `orange`'s preview in a medium size: 

## Mission 4

- Which is the drink with ID `13938`?: AT&T

## Mission 5

- Show us a `random` cocktail: https://www.thecocktaildb.com/api/json/v1/1/random.php

## Mission 6

- Show all cocktail `categories`: https://www.thecocktaildb.com/api/json/v1/1/list.php?c=list

## Bonus

- Find one API where you can limit the pages of reponse by yourself and explain how it works.
- Yes... Of course it can't be thecocktaildb.com, you can try [ProgrammableWeb Directory](https://rapidapi.com/collection/list-of-free-apis) for example

--== Google Custom Search JSON API ==--
Steps to use the Google Search API:

    Get an API key:
      -  Go to Google Cloud Console.
      -  Create a new project or select an existing one.
      -  Enable the Custom Search API.
      -  Generate an API key.

    Set up a custom search engine:
      -  Go to Google Custom Search.
      -  Create a new search engine and configure the domains you want to search.
      -  Get the search engine ID (cx).

## Submission

Upon completion, run the following commands:
```
$ git add .
$ git commit -m "done"
$ git push origin main
```

Then create a Pull Request!!

## Extra Resources

- [JSON](https://www.json.org/)
- [POSTMAN](https://learning.getpostman.com/docs/postman/sending_api_requests/requests/)


![happy_coding](https://user-images.githubusercontent.com/970858/63899010-c23fc480-c9ea-11e9-84a2-542907e42362.png)
