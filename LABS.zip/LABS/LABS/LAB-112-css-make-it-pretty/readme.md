![](https://user-images.githubusercontent.com/970858/63474771-d6734700-c469-11e9-83bb-9429da563909.png)


# CSS | Make it Pretty

## Introduction

> ***Note:*** _This can be a pair programming activity or done independently._

This Lab has two parts:

1. Mastering CSS Selectors
1. Cloning Instagram homepage

Ready??

## Requirements

- [Learn how to fork this repo](https://guides.github.com/activities/forking/)
- Clone this repo into your `code/labs` folder


## Iteration #1

Today we'll be practicing lots and lots of selectors in the [CSS Diner](https://flukeout.github.io/) interactive exercise!

![](./images/flukeout.png)

You have to complete the 32 exercises to pass this lab, good luck!

## Iteration #2

One of the best ways to sharpen your CSS skills is to try to recreate an existing style and layout, so take a look at the deliverable below, work with a partner, and build your own version of Instagram.com.

![](images/instagram.png)

Don't worry if you can't get it to look _exactly_ as you see but try your best to get as close as possible.

### Requirements

- Use [display](https://developer.mozilla.org/en-US/docs/Web/CSS/display), [clear](https://developer.mozilla.org/en-US/docs/Web/CSS/clear), and [floats](https://developer.mozilla.org/en-US/docs/Web/CSS/float) to position elements on the page
- Look up in [MDN](https://developer.mozilla.org/en/) and use CSS properties and values that may not have been covered in class, for example:
  - `background: url("YOUR-LINK.COM")`
  - `list-style`
  - `text-decoration`
  - `text-transform`
- Use a single external CSS stylesheet to style all pages
- Use the images provided to construct the appropriate elements on the page:
  - the iPhone
  - App Store and Google Play buttons
  - Instagram Logo
  - Login button

The `starter-code` contains all the files, images, and text content needed to create the page. The text is in the `index.html`, and the color palette is in `main.css`

To preview your work, click on the Live Server button that is located on the bottom-right corner of VSCode

## Bonus

No Bonus in this lab, we think it should be enough!

## Submission

Upon completion, run the following commands:

```
$ git add .
$ git commit -m "done"
$ git push origin main
```

Then create a Pull Request!!


![happy_coding](https://user-images.githubusercontent.com/970858/63899010-c23fc480-c9ea-11e9-84a2-542907e42362.png)
