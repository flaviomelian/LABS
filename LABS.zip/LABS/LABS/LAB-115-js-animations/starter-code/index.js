var button = document.getElementById('start-stop');
var box = document.getElementById('box');
var boxTop = 60;
var boxTop1 = 60;
var direction = 1;
var box1 = document.getElementById('box1');
var direction1 = 1;
var speed = 10 * direction;
var count = 0;

const moveBox = function () {
  if (boxTop > 500 || boxTop < 60) { direction *= -1; }
  boxTop += speed * direction
  box.style.top = boxTop + 'px';
  if (boxTop == 0) timerId = setInterval(moveBox, 1000);
}

const moveBox1 = function () {
  console.log("yellow")
  if (boxTop1 > 500 || boxTop1 < 60) {
    direction1 *= -1;
  }
    
  boxTop1 += speed * direction1
  box1.style.top = boxTop1 + 'px';
  if (boxTop1 % 100 === 0){
    timerId = setTimeout(moveBox1, 1000);
    console.log("manueh")
  } 
}

var moving = false;
var timerId;
let timerId1 

button.addEventListener("click", function (e) {
  console.log(moving)
  if (!moving) {
    direction = 1;
    direction1 = 1;
    timerId = setInterval(moveBox, 100);
    timerId1 = setInterval(moveBox1, 100);
    button.innerText = "STOP";
    button.classList.remove("green");
    button.classList.add("red");
    speed *= 2
  } else {
    direction = 0;
    direction1 = 0;
    clearInterval(timerId);
    clearInterval(timerId1);
    button.innerText = "START";
    button.classList.remove("red");
    button.classList.add("green");
    count++
  }
  moving = !moving;
})