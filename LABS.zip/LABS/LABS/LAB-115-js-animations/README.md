![](https://user-images.githubusercontent.com/970858/63474771-d6734700-c469-11e9-83bb-9429da563909.png)

# JS Animations

## Introduction

> ***Note:*** _This can be a pair programming activity or done independently._

Today has been all about Animations, so we are goint to practice some moving things in the screen!

There's a bit of starter code, so you can jump right into it.

## Requirements

- [Learn how to fork this repo](https://guides.github.com/activities/forking/)
- Clone this repo into your `code/labs` folder

## Starter code

You will be working in the `starter-code` folder. You have separated: `index.html`, `styles.css` and of course, our friend `index.js`.

We believe in you!

## ITERATIONS
### Iteration 1 - Managing Speed
1. To start off, make the blue box go at half the current speed by default (ie: 200ms)
2. Now make it so every time you `stop` & `restart`, it will go at double the previous speed

### Iteration 2 - Adding Elements
1. Add another box to the right of the current one, this one should be `yellow`, same height but half the width
2. Make the yellow box move at the same speed as the `blue` box

### Iteration 3 - Moving different Elements _differently_
1. Make the yellow box stop, for 1 second, every time it reaches `100px` from the top
2. Make the blue box stop, for 3 seconds, every time it reaches the bottom

### BONUS
1. Change iteration 3 point 1, to stop yellow box every `100px`.

## Submission

Upon completion, run the following commands:

```
$ git add .
$ git commit -m "done"
$ git push origin main
```

Then create a Pull Request with both your names!!

![happy_coding](https://user-images.githubusercontent.com/970858/63899010-c23fc480-c9ea-11e9-84a2-542907e42362.png)
