const express = require("express");
const chucky = require("chucknorris-io");
const client = new chucky();
const api = express();
const port = 3000;
let animalArray = [
  "animal",
  "career",
  "celebrity",
  "dev",
  "explicit",
  "fashion",
  "food",
  "history",
  "money",
  "movie",
  "music",
  "political",
  "religion",
  "science",
  "sport",
  "travel",
];

api.listen(port, () => {
  console.log(`puerto ${port} levantado`);
});

api.get("/random", (request, response) => {
  client
    .getRandomJoke()
    .then(function (res) {
      response.send(res);
    })
    .catch(function (err) {
      response.send(err);
    });
});

api.get("/category", (request, response) => {
  let ret = animalArray.map((category) => {
    return `<li>${category}:<a href="http://localhost:3000/categories/${category}"></a></li>`;
  });
  response.send(`<ul>${ret}</ul>`);
});

api.get(":category/random", (request, response) => {
  client
    .getRandomJoke(request.params.category)
    .then(function (res) {
      response.send(res);
    })
    .catch(function (err) {
      response.send(err);
    });
});
