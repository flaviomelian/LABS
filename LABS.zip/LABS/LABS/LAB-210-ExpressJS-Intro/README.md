![](https://user-images.githubusercontent.com/970858/63474771-d6734700-c469-11e9-83bb-9429da563909.png)

# Express | Chuck Norris Jokes

## Introduction

> ***Note:*** _This can be a pair programming activity or done independently._

## Learning Goals

After this learning unit, you will be able to:

- Create a basic web application using Express
- Get in touch for the first time with an API
- Create a request to the Chuck Norris API to retrieve content and display it
- Add a static route to display content

## Requirements

- [Fork this repo](https://guides.github.com/activities/forking/)
- Clone this repo into your `~/code/labs`

## Deliverables

Please, push every file needed to make your app properly on GitHub before creating the pull request.

## Introduction

[Chuck Norris](https://en.wikipedia.org/wiki/Chuck_Norris) is a famous actor and martial artist that starred in many American movies in the '80s and '90s.

![Chuck Norris Picture](http://3.bp.blogspot.com/-2-VxKrOnOWs/U8zgYIzC5_I/AAAAAAAAWjY/fb-Kr-XQ-pw/s1600/chuck-norris-dont-write-code.jpg)

After his film career died off, the *people of the internet* turned him into a living meme. [Chuck Norris Facts](https://en.wikipedia.org/wiki/Chuck_Norris_facts) quickly became all the rage. These "facts" are just hyperbolic jokes on the skills of Chuck Norris.

> Chuck Norris counted to infinity... twice

> Chuck Norris can put out a fire... with gasoline

> Michael Jackson can moonwalk but Chuck Norris can sun walk

Today, we will be building a Chuck Norris joke finder using Express.

## Setting up a new project

Once you fork this repo, remember to initialize a new project

```
$ npm init -y
```

Install `express` into your project

At the end of the exercise you should have at least four routes:

- `/random`- To display a random joke
- `/categories` - To display joke categories
- `/categories/<category>` - To display a joke by category
- `/search` - To search for a joke by keyword


## Iteration 1 - Get a random joke

To retrieve data from the API, we need to install a package: [chucknorris-io](https://www.npmjs.com/package/chucknorris-io):

```
$ npm install --save chucknorris-io
```

Remember you need to require the package once installed. In this case it will be:

```javascript
const Chuck    = require('chucknorris-io');
const client   = new Chuck();
```

Create a route using Express for the `/random` Web address.

When a user visits http://localhost:3000/random, the application should request a random joke using the `chucknorris-io` package and show it in a `p` tag.

The package has a `getRandomJoke()` method that you should use here:

```javascript
// Retrieve a random chuck joke
client.getRandomJoke()
  .then((response) => {
    // use the response here
  }).catch((err) => {
    // handle error
  });
```


## Iteration 2 - Get Joke Categories

To be able to filter our jokes by category, first we need to display the available categories.

Create a new route `/categories` in your Express application. When a user visits http://localhost:3000/categories with POSTMAN, the application should show the full list of joke categories.

The [chucknorris-io](https://www.npmjs.com/package/chucknorris-io) package offers a method to retrieve the available categories:

```javascript
client.getJokeCategories()
  .then((response)=>  {
    // use the response here
  })
  .catch((err)=> {
    // handle error
  });
```

:bulb: When your app requests the list of categories to the Chuck Norris API, the response will be an array:

```js
[ 'animal',
  'career',
  'celebrity',
  'dev',
  'explicit',
  'fashion',
  'food',
  'history',
  'money',
  'movie',
  'music',
  'political',
  'religion',
  'science',
  'sport',
  'travel' ]
```

In your response each category should be a link. When a user requests one of them with POSTMAN, they should receive the category jokes. For example:

```
[
  animal: http://localhost:3000/categories/animal
  career: http://localhost:3000/categories/career
  ...
]
```

## Iteration 3 - Get Joke Categories random Joke


In your `app.js`, create a new route with the name of the selected category as a parameter in the Web address

Use this parameter to make the request to the API using the `getRandomJoke()` method provided by the [chucknorris-io](https://www.npmjs.com/package/chucknorris-io) package. The method can receive the name of a category as an argument.

```javascript
// Retrieve a random chuck joke
client.getRandomJoke('dev')
  .then((response) => {
    // use the response here
  }).catch((err) => {
    // handle error
  });
```

It should return something like:
```
<p>No statement can catch the ChuckNorrisException.</p>
```


## BONUS - Get a joke by keyword

Users with Postman may need a field to enter the keyword that your application will use to request the joke.

Create a new post route `/search` to capture the POST data sent from POSTMAN. In this route, let's perform the search using the [chucknorris-io](https://www.npmjs.com/package/chucknorris-io) package.

```javascript
client.search(searchTerm)
  .then(function (response) {
    // to stuff here
  }).catch(function (err) {
    // handle error
  });
```

Your function should return an array of jokes for that query using the `res.json()` method.

If no jokes where found, it should return a `sorry dude, not funny terms where found`.


## Extra Resources

- [Express Routing](https://expressjs.com/en/guide/routing.html)
- [chucknorris-io](https://www.npmjs.com/package/chucknorris-io)

## Submission

Upon completion, run the following commands:

```
$ git add .
$ git commit -m "done"
$ git push origin main
```

Then create a Pull Request!!


![happy_coding](https://user-images.githubusercontent.com/970858/63899010-c23fc480-c9ea-11e9-84a2-542907e42362.png)
