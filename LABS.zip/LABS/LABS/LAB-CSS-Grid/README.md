![](https://user-images.githubusercontent.com/970858/63474771-d6734700-c469-11e9-83bb-9429da563909.png)

# LAB-CSS-Grid

## Introduction

The mission today is to replicate different types of common layouts using CSS Grid and practice all the different attributes.

## Iteration 1 - Header+Content+Footer

The first layout is a simple one. It contains a Header, a main section and a footer.

![](assets/iteration1.png)

To complete:
1. Please go to the `student_code/iteration1` folder and open both `index.html` and `styles.css` in VSCode
1. Create a `#container` div with `display: grid;`
1. Add inside the [header](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/header), [main](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/main) and [footer](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/footer) semantic sections with some text inside and different background colors for each
1. Style so that the `header` and `footer` are `40px`, but the `main` section is taking the rest of the available space (ie. `1fr`)
1. Add some padding to the content to make it look like the image

## Iteration 2 - 12 Grid Columns

Typically, responsive design systems rely on the concept of a grid system, in which columns have equal size, but we can have our div taking anywhere from 1 (1/12 of the space) to 12 columns (full-width).

![](assets/iteration2.png)

We will be implementing a 12 column grid system and play with it.

1. Please go to the `student_code/iteration2` folder and open both `index.html` and `styles.css` in VSCode
1. Create a `container` div with 12 divs inside with the class `.column`
1. Inside each `column`, add text inside with the column number. Ie. consecutive numbers starting from 1, finishing in 12 (check image above)
1. Position the `container` to take full-screen (width & height)
1. Change `container` display property to `display: grid`
1. Add 12 columns, same size, with `grid-template-columns`
1. Add a gap between columns of `12px`
1. Add some light background color to the `.column` and enjoy the result!

## Iteration 3 - Sidebar/Main

![](assets/iteration3a.png)

Now we continue from the code from Iteration 1, where we added a `header`, `main` and `footer`. The goal is to use css grid to divide the `main` section into two parts:

- Sidebar (3 columns)
- Content (9 columns)

![](assets/iteration3b.png)

Copy the finished code from the `iteration1` folder (`index.html`, `styles.css`) into the `iteration3` folder to get started.

To finish this iteration you will have to:

1. Wrap the `main` section with a div `id` named `main-grid`
1. Add an `aside` element before `main`, with an `h2` and the text `SIDEBAR`
1. Make sure `main-grid` is using display grid and create, a 12-column grid template (like iteration2)
1. Add some background-color to `.sidebar` and make sure it takes only 3 columns
1. Make sure `main` is taking the rest of space (9 columns)
1. Try resizing the window and see that everything makes senses

As you resize and make it samll, Can you see the sidebar gets way too narrow? Try and solve it using `min-width`!

## Iteration 4 - Add Breadcrumbs bar

Between the header and the content (sidebar+main), we are going to add a breadcrumb bar, so our users will know where we are on the site at every page.

![](assets/iteration4.png)

Now it's your turn to make it by yourself with everything that you have learnt!

## BONUS - Create another sidebar on the right

If you are feeling adventurous, you can try and create another smaller sidebar on the right, like this picture:

![](assets/iteration-bonus.png)

Happy coding hacker!

## Submission

Upon completion, run the following commands:

```
$ git add .
$ git commit -m "done"
$ git push origin main
```

Then create a Pull Request!!

![happy_coding](https://user-images.githubusercontent.com/970858/63899010-c23fc480-c9ea-11e9-84a2-542907e42362.png)
