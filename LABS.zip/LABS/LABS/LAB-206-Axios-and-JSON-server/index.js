const api = require("./api.js"); //OBTENER MI PUTA API
const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
const showMenu = () => {
  console.log(`
  Welcome to TODO App!
  1. Show All Todos
  2. Show One Todo
  3. Create new Todo
  4. Update one Todo
  5. Delete one Todo
  6. Exit
  `);

  rl.question("Choose an option: ", (choice) => {
    switch (choice) {
      case "1":
        async (id) => {
          try {
            const data = await api.get(
              `https://jsonplaceholder.typicode.com/todos`
            );
            console.log(data);
          } catch (error) {
            throw new Error(error);
          } finally {
            showMenu();
          }
        };
        break;
      case "2":
        rl.question("Please, give a todo id: ", async (id) => {
          try {
            const data = await api.get(
              `https://jsonplaceholder.typicode.com/todos/${id}`
            );
            console.log(data);
          } catch (error) {
            throw new Error(error);
          }
        });
        break;
      case "3":
        rl.question("Create a new todo: ", async (todo) => {
          try {
            const { data } = await api.post(
              `https://jsonplaceholder.typicode.com/todos/`,
              {
                userId: 1,
                title: todo,
                completed: false,
              }
            );
            console.log(data);
          } catch (error) {
            throw new Error(error);
          }
        });
        break;
      case "4":
        rl.question(
          "Please, give a todo id to update and the new content: ",
          async (id, todo) => {
            try {
              const { data } = await api.put(
                `https://jsonplaceholder.typicode.com/todos/${id}`,
                {
                  userId: 1,
                  title: todo,
                  completed: true,
                }
              );
              console.log(data);
            } catch (error) {
              throw new Error(error);
            }
          }
        );
        break;
      case "5":
        rl.question("Please, give a todo id to delete: ", async (id) => {
          try {
            const data = await api.delete(
              `https://jsonplaceholder.typicode.com/todos/${id}`
            );
            console.log(data);
          } catch (error) {
            throw new Error(error);
          }
        });
        break;
      case "6":
        rl.close();
        break;
      default:
        console.log("Invalid option");
        showMenu();
        break;
    }
  });
};

showMenu();
//CRUD:
/*const showAllTodos = async () => {
  try {
    const data = await api.get(`https://jsonplaceholder.typicode.com/todos/`);
    console.log(data);
  } catch (error) {
    throw new Error(error);
  } finally {
    showMenu();
  }
};

const showOneTodo = async (id) => {
  try {
    const data = await api.get(
      `https://jsonplaceholder.typicode.com/todos/${id}`
    );
    console.log(data);
  } catch (error) {
    throw new Error(error);
  } finally {
    showMenu();
  }
};

const createTodo = async (todo) => {
  try {
    const { data } = await api.post(
      `https://jsonplaceholder.typicode.com/todos/`,
      {
        userId: 1,
        title: todo,
        completed: false,
      }
    );
    console.log(data);
  } catch (error) {
    throw new Error(error);
  } finally {
    showMenu();
  }
};

const updateTodo = async (id, todo) => {
  try {
    const { data } = await api.put(
      `https://jsonplaceholder.typicode.com/todos/${id}`,
      {
        userId: 1,
        title: todo,
        completed: true,
      }
    );
    console.log(data);
  } catch (error) {
    throw new Error(error);
  } finally {
    showMenu();
  }
};

const deleteTodo = async (id) => {
  try {
    const data = await api.delete(
      `https://jsonplaceholder.typicode.com/todos/${id}`
    );
    console.log(data);
  } catch (error) {
    throw new Error(error);
  } finally {
    showMenu();
  }
};*/
