![](https://user-images.githubusercontent.com/970858/63474771-d6734700-c469-11e9-83bb-9429da563909.png)

# LAB-206-Axios-and-JSON-server

## Introduction

> ***Note:*** _This can be a pair programming activity or done independently._

Today we have learnt about creating APIs with JSON-Server and how to consume them by making requests with Axios. But as we know, we learn by doing!! Let's create our own API to practice some modelling and request data with the Axios package.!

## Requirements

- [Learn how to fork this repo](https://guides.github.com/activities/forking/)
- Clone this repo into your `code/labs` folder
- You need use readline for this lab.
- Make sure you have `json-server` installed as a global package
- Install axios with ǹpm iinstall axios`

## Project Description

Today we are going to create an API: our TODO list!

We are expected to have a fully functional API with JSON-SERVER that fulfills the basic needs of TODO apps:
- Get
- Post
- Delete
- Update

## Iteration 1 - Setup Backend

First things first! We can't have our TODO app running without a backend. Your first goal is to run the backend in your console with the command `json-server --watch db.json` and modify the structure of the db.json file and adjust it with a collection named TODO, with the following fields:
- id
- todo
- a field indicating whether it is pending or done

<br/>

We will also create a USER collection with the fields:
- id
- name
- email

When we have the correct structure we will introduce test data to it. After running it, you will be able to check if everything works in Postman.

We already have our backend up and running!

## Iteration 2 - Configure axios instance

Now we have to create our logic to consume it. Let's create an instance of axios and set the variable baseURL with your backend URL. Don´t forget to require it.

## Iteration 3 - Create a Welcome Menu

First we need to implement a simple menu with [readline](https://nodejs.org/api/readline.html#rlquestionquery-options-callback). We will show in the console the different requests that we can make in our small app:

  1. Show All Todos 
  2. Show One Todo
  3. Create new Todo
  4. Update one Todo
  5. Delete one Todo
  6. Exit

- Tip: You can show the available options in the console and wait (readline) for the user to indicate the option he wants, and use a switch to execute the option the user needs.

## Iteration 4 - Get All TODOS

We already saw how to implement a TODO list that stores its TODOs in a file. However, you would not have storage in the same place as the code. Normally, the server will have to send the data through HTTP requests to a database located in another server. You'll have to replicate that using your new API (http://localhost:3000) and make the request with the new axios superpowers.

- You have to implement the function `getAllTodos()` to get all your TODOs from the backend and show the result in console using [axios](https://github.com/axios/axios) and `readline`, it should wait for any input on the command line.

- This function would output something like this:

```js
[
  { id: 1, todo: 'json-server', done: 'false' },
  { id: 2, todo: 'API', done: 'false' },
  { id: 3, todo: 'Axios', done: 'false' },
  { id: 4, todo: 'Create DB', done: 'false' },
  { id: 5, todo: 'Create Models', done: 'false' },
  { id: 6, todo: 'Insert Data', done: 'false' },
  { id: 7, todo: 'json-server', done: 'false' }
]

```

## Iteration 5 - Create TODO

In your app you will have a form with some values to create your new TODO. In this case you have to implement a function `createTodo()` that collects the data of the TODO. At the end we show in the console the new TODO that is going to be created and we will ask for confirmation to create it.

- Tip: The readline command can be chained, and request the data that we need one by one. We can store these data in a variable (object) that contains all the information of our TODO.


## Iteration 6 - Get One TODO, Delete TODO and Update TODO

Well, now we can read and create data in our API.  It's time to implement the functions where we request, update or delete a specific TODO.

- Create 3 functions `updateOneTodo()`,`getOneTodo()` and `deleteOneTodo()`

- Tip: In these 3 functions you will need to ask the user for the ID of the TODO that he wants to request, update or delete.

## Iteration 7 - Implement User CRUD

Implement the user CRUD to the app by modifying the start menu to add new options.

## Submission

Upon completion, run the following commands:

```
$ git add .
$ git commit -m "done"
$ git push origin main
```

Then create a Pull Request!!

![happy_coding](https://user-images.githubusercontent.com/970858/63899010-c23fc480-c9ea-11e9-84a2-542907e42362.png)


