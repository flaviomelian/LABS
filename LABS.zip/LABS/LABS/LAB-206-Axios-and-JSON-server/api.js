const axios = require("axios");

//CREAR LA API:
const api = axios.create({
  baseURL: "http://localhost:3000/",
});

//EXPORTAR LA API:
module.exports = api;
