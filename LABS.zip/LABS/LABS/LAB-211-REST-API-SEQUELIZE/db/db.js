const e = require("express");
const { Sequelize } = require("sequelize");
const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWD,
  {
    host: process.env.DB_HOST,
    dialect: process.env.DIALECT,
    port: process.env.DB_PORT3306,
    logging: false,
  }
); //conexion a la base de datos

//funcion que se encarga de establecer la conexion:
const checkConnection = async () => {
  try {
    await sequelize.authenticate(); //metodo de sequelize que te conecta a la base de datos
    console.log("entro");
  } catch (error) {
    console.error(error);
  }
};

//configuracion para poder crear los modelos:
//manejo de la creacion y actualizacion de los modelos:
const syncModels = async () => {
  try {
    await sequelize.sync(); //actualizamos las tablas con sync de sequelize
  } catch (error) {
    console.error(error);
  }
};

module.exports = { checkConnection, syncModels, sequelize }; //exportamos las funciones
