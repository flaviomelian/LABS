const User = require("../api/models/user.model"); //importar el modelo del usuario
const Movie = require("../api/models/movie.model"); //importar el modelo de la peli
const Actor = require("../api/models/actor.model");

const addRelationsToModels = () => {
  //Funcion que añade las relaciones entre los modelo
  try {
    Actor.belongsToMany(Movie, {
      through: "actors_movies",
      timestamps: false,
    });

    Movie.hasMany(Actor, {
      through: "movies_actors",
      timestamps: false,
    });

    console.log("Relations added to models");
  } catch (error) {
    console.error(error);
  }
};

module.exports = addRelationsToModels;
