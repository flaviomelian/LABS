const { Sequelize } = require("sequelize");

const sequelize = new Sequelize("Ristorante", "flavio", "flavio", {
  host: "localhost",
  dialect: "mysql",
  port: 3306,
  logging: false,
});

async function checkConnection() {
  try {
    await sequelize.authenticate();
    console.log("Connection to DB has been established successfully.");
  } catch (error) {
    throw error;
  }
}

async function syncModels() {
  try {
    await sequelize.sync();
    console.log("All models were synchronized successfully.");
  } catch (error) {
    throw error;
  }
}

module.exports = { sequelize, checkConnection, syncModels };
