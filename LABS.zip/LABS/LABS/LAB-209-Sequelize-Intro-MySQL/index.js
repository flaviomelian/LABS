const { sequelize, checkConnection, syncModels } = require("./db_connection");
const Recipe = require("./models/recipe");

/*const Recipe = sequelize.define("Recipe", {
  title: { type: DataTypes.STRING },
  level: { type: DataTypes.STRING },
  ingredients: { type: DataTypes.STRING },
  cuisine: { type: DataTypes.STRING },
  dishType: { type: DataTypes.STRING },
  image: { type: DataTypes.STRING },
  duration: { type: DataTypes.INTEGER },
  creator: { type: DataTypes.STRING },
  created: { type: DataTypes.DATE },
});*/

(async function () {
  try {
    await Recipe.sync({ alter: true });
  } catch (error) {
    console.error(error);
  }
})();

async function createRecipe() {
  const recipe = await Recipe.create({
    title: "LOLO",
    level: "HIGH",
    ingredients: "INGREDIENTS",
    cuisine: "LA CUISINE",
    dishType: "EL CALDERO",
    image: "IMAGE",
    duration: 25,
    creator: "ME",
    created: "2024-06-05 15:26:01",
  });
}

async function createManyRecipes() {
  const recipe = await Recipe.bulkCreate([
    {
      title: "LOLO",
      level: "HIGH",
      ingredients: "INGREDIENTS",
      cuisine: "LA de mi casa",
      dishType: "EL CALDERO",
      image: "IMAGE",
      duration: 20,
      creator: "ME",
      created: "2024-05-15 15:26:01",
    },
    {
      title: "LaLO",
      level: "fleje",
      ingredients: "los que sean",
      cuisine: "LA CUISINE",
      dishType: "EL CALDERO",
      image: "IMAGE",
      duration: 25,
      creator: "ME",
      created: "2024-06-05 15:26:01",
    },
  ]);
}

//createManyRecipes();
//createRecipe();

async function updateRecipe(level) {
  const recipe = await Recipe.update(
    {
      title: "coño",
    },
    {
      where: {
        level: level,
      },
    }
  );
}

updateRecipe("fleje");

async function removeRecipe(title) {
  const recipe = await Recipe.destroy({
    where: {
      title: title,
    },
  });
}

removeRecipe("coño");
sequelize.close();
// ADD SEQUELIZE QUERIES HERE AND CHECK THE RESULT WITH TABLE PLUS
