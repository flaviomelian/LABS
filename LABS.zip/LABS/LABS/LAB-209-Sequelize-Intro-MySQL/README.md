![](https://user-images.githubusercontent.com/970858/63474771-d6734700-c469-11e9-83bb-9429da563909.png)


# JS Sequelize introduction

## Introduction

> ***Note:*** _This can be a pair programming activity or done independently._

In this lesson we have learnt how to use MySQL from node with Sequelize. Using models to implement queries and CRUD operations.

In the following exercise, we will practice how to implement this by creating awesome recipes.

## Requirements

- [Learn how to fork this repo](https://guides.github.com/activities/forking/)
- Clone this repo into your `code/labs` folder

## Starter code

This is a basic node lab, so we have just created an `./index.js` that you can run writting `node index.js`.

You have to install "all the packages" we required in the `package.json`.

So just download it and `npm i` for start!

---
## Instructions

Create a recipe DB using TablePlus, remember you always need an already created DB to connect.

### Iteration 1 - Recipe Model

Create a `Recipe` model inside the file `/models/recipe.js`. The model should have the following fields:

- **title**. Type `String`.
- **level**. Type `String`.
- **ingredients**. Type `String`.
- **cuisine**. Type `String`.
- **dishType**. Type `String`.
- **image**. Type `String`.
- **duration**. Type `Number`.
- **creator**. Type `String`
- **created**. Type `Date`.

### Iteration 2 - Create a recipe

In `index.js`, and after created and declared the model, using the [`Model.create`](https://sequelize.org/docs/v6/core-concepts/model-querying-basics/) method, you should pass the info to create a new recipe. After the creation, you can use TablePlus to check everything goes ok. After inserting the recipe, you should `console.log` the `title` of the recipe.

**To run your code, remember you should use `$ node index.js`.**

### Iteration 3 - Insert Many recipes

Using the [`Model.bulkCreate`](https://sequelize.org/docs/v6/core-concepts/model-querying-basics/) method, you should add an entire array of 6 recipes to the database. After inserting the elements, print on the console the title of each recipe.

### Iteration 4 - Update recipe

Now you should have six different recipes in the database, but there was a mistake in one of them. You should update the `duration` field of one of them and set it to **60**. After updating it, print a success message!

### Iteration 5 - Remove a recipe

Using the [`Model.destroy`](https://sequelize.org/docs/v6/core-concepts/model-querying-basics/) method, remove one recipe from the database and display a success message after doing it!

### Iteration 6 - Close the Database

After doing all the task you should close the database. Otherwise, the connection will keep open. Be careful about the asynchrony of all process; you should close it after everything is done! 😉
[`Sequelize connection`](https://sequelize.org/docs/v6/getting-started/)

Happy coding! 😍


---


## Bonus

**Should I validate this data?**

Next week we will learn more about the Models. Right there we can put validations in the fields :)

If you are curious about how this information could be validated before creating recipes in an erroneous way, that is the bonus of this lab. Google it! "How to validate Sequelize model"



## Submission

Upon completion, run the following commands:

```
$ git add .
$ git commit -m "done"
$ git push origin main
```

Then create a Pull Request!!

![happy_coding](https://user-images.githubusercontent.com/970858/63899010-c23fc480-c9ea-11e9-84a2-542907e42362.png)
