const { DataTypes } = require("sequelize");
const { sequelize } = require("../db_connection");

const Recipe = sequelize.define("recipe", {
  title: { type: DataTypes.STRING },
  level: { type: DataTypes.STRING },
  ingredients: { type: DataTypes.STRING },
  cuisine: { type: DataTypes.STRING },
  dishType: { type: DataTypes.STRING },
  image: { type: DataTypes.STRING },
  duration: { type: DataTypes.INTEGER },
  creator: { type: DataTypes.STRING },
  created: { type: DataTypes.DATE },
});

module.exports = Recipe;
