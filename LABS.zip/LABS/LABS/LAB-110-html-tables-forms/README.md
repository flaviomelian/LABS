![](https://user-images.githubusercontent.com/970858/63474771-d6734700-c469-11e9-83bb-9429da563909.png)


# HTML Tables & Forms

## Introduction

> ***Note:*** _This can be a pair programming activity or done independently._

Today has been all about tables and forms, so let's make a website that uses all of that usefully.

There's a bit of starter code, so you can jump right into it.

## Requirements

- [Learn how to fork this repo](https://guides.github.com/activities/forking/)
- Clone this repo into your `code/labs` folder

## Starter code

You will be working in the `starter-code` folder. You have two separate files: `forms.html` and `tables.html`.

In this exercise you will only have **one css file**: `main.css` so you'll have to make sure that the css you write will not affect the other file.

To preview your work, click on the Live Server button that is located on the bottom-right corner of VSCode

We believe in you!

## Deliverable

Please find a screenshot of the expected results below:

### Iteration 1

Write the following table in `tables.html` using as much Semantic HTML as possible:

![Final Table](images/final-table.png)

### Iteration 2
The second iteration is all about forms. You'll have to work on `forms.html` to recreate the following form:

![Final Form](images/final-form.png)

The full list of countries for the form is:
- Spain
- France
- Germany
- Italy
- Japan
- Russia
- United Kingdom
- United States

## Bonus

1. Add some styling to make it super nice!
1. Add in `tables.html` a footer row that shows the AVERAGE of all players for goals and assists
1. Add in `forms.html` some styling to make all inputs aligned :)

## Submission

Upon completion, run the following commands:

```
$ git add .
$ git commit -m "done"
$ git push origin main
```

Then create a Pull Request!!


![happy_coding](https://user-images.githubusercontent.com/970858/63899010-c23fc480-c9ea-11e9-84a2-542907e42362.png)
