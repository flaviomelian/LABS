function deleteItem(e){
  console.log(e.target.parentNode.parentNode)
  e.target.parentNode.parentNode.removeChild(e.target.parentNode)
}

function getPriceByProduct(itemNode){

}

function updatePriceByProduct(productPrice, index){

}

function getTotalPrice() {
  let items = document.getElementsByClassName("product")
  let total = 0
  console.log(items.length)
  for (let i = 0; i < items.length; i++){
    console.log(items[i].getElementsByClassName("price")[0].textContent)
    total += parseInt(items[i].getElementsByClassName("price")[0].textContent)
  }
/* 
  let div = document.createElement("p")
  div.setAttribute("class", "total")
  document.getElementsByTagName("body")[0] */
  document.getElementById("total").innerText = "Total Price " + total + " €"
}

function createNewItemRow(itemName, itemUnitPrice, itemPrice){
  console.log("arrive", itemName, itemUnitPrice, itemPrice)
  let div = document.createElement("div")
  div.setAttribute("colspan", "5")
  div.appendChild(createNewItem(itemName, itemUnitPrice, itemPrice))
  console.log("done")
  document.getElementsByClassName("products")[0].appendChild(div)
}

function createNewItem(itemName, itemUnitPrice, itemPrice){
  console.log("hi0", itemName, "-", itemUnitPrice, "-", itemPrice)
  console.log(document.getElementsByClassName("price-value")[0].value)
  let div = document.createElement("div")
  div.setAttribute("class", "product")
  let paragraph = document.createElement("p")
  paragraph.setAttribute("class", "name")
  paragraph.innerText = document.getElementsByClassName("product-name")[0].value
  div.appendChild(paragraph)
  paragraph = document.createElement("p")
  paragraph.setAttribute("class", "item-price")
  paragraph.innerText = document.getElementsByClassName("price-value")[0].value
  div.appendChild(paragraph)
  paragraph = document.createElement("input")
  paragraph.setAttribute("type", "text")
  div.appendChild(paragraph)
  paragraph = document.createElement("p")
  paragraph.setAttribute("class", "price")
  paragraph.innerText = document.getElementsByClassName("price-value")[0].value + " €"
  div.appendChild(paragraph)
  button = document.createElement("button")
  button.setAttribute("class", "btn-delete")
  button.innerText = "delete"
  button.onclick = deleteItem;
  div.appendChild(button)
  console.log("INNER-HTML", div.innerHTML)
  return div
}

window.onload = function(){
  //createNewItemRow()
  //createNewItemRow("camiseta", "20", 10)
  //createNewItemRow("pantalones", "25", 20)
  var calculatePriceButton = document.getElementById('calc-prices-button');
  //calculatePriceButton.addEventListener("click", getTotalPrice) llamada del diablo
  calculatePriceButton.onclick = getTotalPrice;
  var createItemButton = document.getElementsByClassName('create')[0];
  //createItemButton.addEventListener("click", createNewItemRow) llamada del diablo
  createItemButton.onclick = createNewItemRow;
  var deleteButtons = document.getElementsByClassName('btn-delete');
  for(var i = 0; i<deleteButtons.length ; i++){
    deleteButtons[i].onclick = deleteItem;
  }
};
