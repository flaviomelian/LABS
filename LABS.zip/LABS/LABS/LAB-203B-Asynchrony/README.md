![](https://user-images.githubusercontent.com/970858/63474771-d6734700-c469-11e9-83bb-9429da563909.png)


# JS Asynchrony

## Introduction

> ***Note:*** _This can be a pair programming activity or done independently._

Today we have learned about asynchrony and promises. To practice them we will be using the NodeJS APIs for file management and become the IT Team of **detective agency Pikachu**.

![image](https://user-images.githubusercontent.com/970858/231989098-8f8bf0f6-d041-4bd7-b1ec-cf0f22deca88.png)

Ready?

## Requirements

- [Learn how to fork this repo](https://guides.github.com/activities/forking/)
- Clone this repo into your `code/labs` folder

## Iteration 1 - Detective's Diary

<img src="https://user-images.githubusercontent.com/970858/232009203-c9dace45-db77-4854-9a76-3555e1accef9.png" height="200" />

Our Pikachu is on a quest to understand why all pokemons are now learning to code. He has been writting a daily diary of all his findings.

Our first goal is to read the detective's diary entries - in a text file named `diary.txt`- to the console using nodeJS.

You should create a function called `readDiary` that receives a file name as a parameter, and logs the content of the file to the console.

You should call the function from the program and run it with `node index.js` to test everything is working!

#### Hints

1. Import the `fs/promises` module: `import fs from 'fs/promises'`
1. Use `fs.readFile('diary.txt', 'utf-8')` to read the file. [docs](https://nodejs.org/dist/latest-v10.x/docs/api/fs.html#fs_filehandle_readfile_options)
1. Don't forget to use `.then()` and `.catch()` to handle the Promise.



## Iteration 2 - Secret Notes

<img src="https://user-images.githubusercontent.com/970858/232009615-dd12d165-2e3b-4e87-83c1-8903f285e363.png" height="200" />

Pikachu just realized that his diary can be read by anyone and he is very scared. Thanks to his knowledge on cryptography, he wants you to encrypt his file so nobody can read it using the famous [Caesar Cipher](https://en.wikipedia.org/wiki/Caesar_cipher).

Your goal is to write a secret version of his diary, in another file, for your fellow yellow detective.

Write a function `encryptDiary` that takes 2 parameters:
- fileName
- encryptedFileName

The function will encrypt all the contents of `diary.txt` and write an encrypted version to a new text file named `secret_diary.txt`. It will read, line by line, `diary.txt` and write an encrypted version in `secret_diary.txt`.

Then, use `readDiary` to verify the contents of the new file and log the secret file to the console.

#### Hints

1. You can use the asynchronous `encrypt` method imported in `index.mjs` to encrypt each line -  `import { encrypt, decrypt} from "./utils.mjs"`
1. Use [`fs.writeFile`](https://nodejs.org/api/fs.html#filehandlewritefiledata-options) to write the secret entry.
1. Chain the Promises using `.then()`, and handle errors with `.catch()`.



## Iteration 3 - Case Files Backup

<img src="https://user-images.githubusercontent.com/970858/232012070-694455f9-91de-4811-8a79-a6696a972b79.png" height="200" />

Pikachu thinks Bulbasurs are following him and he wants to make a backup copy of an important case file!!

You should create a function `backup` that copies an existing text file named `secret_diary.txt` to a new file named `secret_diary_backup.txt`.

Read the contents of the new file with `readDiary` and log it to the console to confirm the backup is working.

#### Hints

1. Use `fs.copyFile(fileOriginal, fileBackup)` to create a backup. [docs](https://nodejs.org/api/fs.html#fspromisescopyfilesrc-dest-mode)
1. Chain the Promises using `.then()`, and handle errors with `.catch()`.



## Iteration 4 - Case Files Analysis

<img src="https://user-images.githubusercontent.com/970858/232011203-5cd02c6e-6210-40dd-bef3-206472dadc70.png" height="200" />

Pikachu is getting more and more paranoid. He thinks that someone has manipulated his diary and wants you to analyze the **file size** and **modification time** of a the `diary.txt` file.

Using [`fs.stat`](https://nodejs.org/api/fs.html#filehandlestatoptions) you have to retrieve the statistics of a text file named `diary.txt`, then log the **file size** and **modification time**  to the console.

- You can use the `getHumanSize(bytes)` function to log the size of the file in a human-friendly way (`3.04 KB`, instead of `3113`)
- You can use the `getRelativeTime(time)` function to log the modification time of a date (ie. `mtime`) in a human friendly way (ie. `2 minutes ago` instead of `2023-04-14T09:12:28.096Z`)

#### Hints

1. Use `fs.stat('case_file.txt')` to get the file statistics.
1. Access the file size using the size property (e.g., `stats.size`).
1. Access the `modification time` using the mtime property (e.g., `stats.mtime`).
1. Use `.then()` and `.catch()` to handle the Promise.


## Submission

Upon completion, run the following commands:

```
$ git add .
$ git commit -m "done"
$ git push origin main
```

Then create a Pull Request!!

![happy_coding](https://user-images.githubusercontent.com/970858/63899010-c23fc480-c9ea-11e9-84a2-542907e42362.png)
