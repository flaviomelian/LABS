// CAESAR CYPHER
/*
In cryptography, a Caesar cipher, also known as Caesar's cipher, the shift cipher, Caesar's code or Caesar shift, is one of the simplest and most widely known encryption techniques. It is a type of substitution cipher in which each letter in the plaintext is replaced by a letter some fixed number of positions down the alphabet.

--> https://en.wikipedia.org/wiki/Caesar_cipher
*/

const SHIFT = 10

// Encrypt function using Caesar Cipher
export async function encrypt(text) {
	return new Promise((resolve) => {
		const encryptedText = text.split('').map(char => {
			const charCode = char.charCodeAt(0)

			if (char.match(/[a-z]/i)) {
				const base = char.match(/[a-z]/) ? 'a'.charCodeAt(0) : 'A'.charCodeAt(0)
				return String.fromCharCode(((charCode - base + SHIFT) % 26) + base)
			}

			return char
		}).join('')

		resolve(encryptedText)
	})
}

// Decrypt function using Caesar Cipher
export function decrypt(encryptedText) {
	return new Promise((resolve) => {

		const decryptedText = encryptedText.split('').map(char => {
			const charCode = char.charCodeAt(0)

			if (char.match(/[a-z]/i)) {
				const base = char.match(/[a-z]/) ? 'a'.charCodeAt(0) : 'A'.charCodeAt(0)
				return String.fromCharCode(((charCode - base - SHIFT + 26) % 26) + base)
			}

			return char;
		}).join('')

		resolve(decryptedText)
	})
}

export async function getRelativeTime(birthTime) {
	return new Promise((resolve) => {

		const now = new Date();
		const diffInSeconds = (now - birthTime) / 1000
		const rtf = new Intl.RelativeTimeFormat('en', { numeric: 'auto' })

		const units = [
			{ unit: 'year', seconds: 60 * 60 * 24 * 365 },
			{ unit: 'month', seconds: 60 * 60 * 24 * 30 },
			{ unit: 'day', seconds: 60 * 60 * 24 },
			{ unit: 'hour', seconds: 60 * 60 },
			{ unit: 'minute', seconds: 60 },
			{ unit: 'second', seconds: 1 }

		]

		for (const { unit, seconds } of units) {
			const value = Math.floor(diffInSeconds / seconds)
			if (Math.abs(value) >= 1) {
				resolve(rtf.format(-value, unit))
			}
		}

		resolve('just now')
	})
}



export async function getHumanSize(bytes) {
	return new Promise((resolve) => {
		const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
		const index = Math.floor(Math.log10(bytes) / 3);
		const size = (bytes / Math.pow(1000, index)).toFixed(2);
		const unit = units[index];

		resolve(`${size} ${unit}`);
	})
}
