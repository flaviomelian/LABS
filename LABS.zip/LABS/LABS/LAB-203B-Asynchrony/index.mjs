import fs from 'fs/promises'
import { encrypt, decrypt } from "./utils.mjs"
import { error } from 'console'

// Your code goes here
// Lectura del fichero
fs.readFile('diary.txt', 'utf-8').then((result) => {console.log(result)}).catch((error) => {console.log(error)}) 

// Encriptar el fichero
const encryptDiary = (fileName, encryptedFileName) => {
    const diary = fs.readFile('diary.txt', 'utf-8')
    diary.then((result) => {
        encrypt(result).then((content) => {
            fs.writeFile(encryptedFileName, content)
        }).catch((error) => {
            console.log(error)
        })
    }).catch((error) => {
        console.log(error)
    }) 
}

// Generar una copia de seguridad
const backup = (fileName, backupName) => {
   fs.copyFile(fileName, backupName)
}

//Analisis del fichero


console.log(encryptDiary('diary.txt', 'secret_diary.txt'))
console.log(backup('secret_diary.txt', 'backup_secret_diary.txt'))