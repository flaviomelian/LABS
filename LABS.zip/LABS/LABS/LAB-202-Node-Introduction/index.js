var argv = require('minimist')(process.argv.slice(2));
console.log(`"Hello, it seems ${process.argv[process.argv.length - 2]} has been ${process.argv[process.argv.length - 1]} late today ...."\n"The punishment for that person today is ..."\n3,\n2,\n1\n"RANDOM PUNISHMENT"`)
console.log(getRandomPunisher(['An entire day at side of Flavio', 'Making an apologize trap', 'Ten push ups shouting "ARRIBA ESPAÑA"', 'Talk with a Russian accent all day']))
function getRandomPunisher(args){
    if (Math.random() >= 0.5) return args[Math.floor(Math.random() * args.length)]
    return args[Math.floor(Math.random() * args.length - 2) + 2]
}