![](https://user-images.githubusercontent.com/970858/63474771-d6734700-c469-11e9-83bb-9429da563909.png)


# JS Node introduction

## Introduction

> ***Note:*** _This can be a pair programming activity or done independently._


Today you have learnt a bit about Node.js, it’s history, and how to install it on your computer. In addition, we learned a bit about what a runtime is.

Today's laboratory will consist of the use of certain modules and specifically the fs module (file system) that is very widely used

Ready?

## Requirements

- [Learn how to fork this repo](https://guides.github.com/activities/forking/)
- Clone this repo into your `code/labs` folder

## Starter code

This is a basic node lab, so we have just created an `./index.js` that you can run writting `node index.js`. 

You have to create the initial `package.json` with the `npm init -y` command before start.

---
## Iteration 1 - Create a bash script

### The basic punisher

In our bootcamp we take it very seriously to arrive early to class. That is why, when someone is late we randomly assign a punishment among those we have defined at the beginning of the bootcamp.

Your mission is to create a script in nodejs that allows you to randomly get a punishment.

This command would be executed as follows and generate the following output:

> node index.js

> "Hello, it seems someone has been late today ...."

> "The punishment for that person today is ..."

> 3

> 2

> 1

> "RANDOM PUNISHMENT"

## Iteration 2 - A custom punisher

[Research the npm minimist package.](https://www.npmjs.com/package/minimist)

Using this package it will be quite easy to receive parameters in your nodejs script.

That is why we want to customize our script so that it can receive the following parameters.

`-n | --name "username" ` In this case we will use this name to personalize the message of the punisher

`-l | --late "time in minutes"` Here we can receive the time in minutes that person has taken. If you are late more than 30 minutes print a special message or choose between different punishments

`-m | --mode "soft | hard"` If you receive the parameter m you could specify the hardness of the punishment that could be soft or hard

If you are lost with this of the parameters or flags, here is an interesting article where they explain it to you. https://medium.com/@jgefroh/a-beginners-guide-to-linux-command-line-56a8004e2471

--- 


## Bonus

**The master punisher**

To become a full master punisher, add the following features to your punisher:

1. Make the output use [chalk](https://www.npmjs.com/package/chalk) to output in fancy colors
1. Tell a random [chuck norris joke](https://www.npmjs.com/package/chucknorris-io) before giving the punishment!



## Submission

Upon completion, run the following commands:

```
$ git add .
$ git commit -m "done"
$ git push origin master
```

Then create a Pull Request!!

![happy_coding](https://user-images.githubusercontent.com/970858/63899010-c23fc480-c9ea-11e9-84a2-542907e42362.png)
